const menuBtn = document.querySelector(".menu-btn");
const nav = document.querySelector("nav");
menuBtn.addEventListener("click", () => nav.classList.toggle("open"));

const modal = document.getElementById("joinModal");
const selectedPlan = document.getElementById("selectedPlan");

document.querySelectorAll(".join-btn").forEach(btn => {
  btn.addEventListener("click", () => {
    selectedPlan.value = btn.dataset.plan;
    modal.classList.add("show");
  });
});

document.querySelector(".close").addEventListener("click", () => modal.classList.remove("show"));
modal.addEventListener("click", e => { if (e.target === modal) modal.classList.remove("show"); });

document.getElementById("membershipForm").addEventListener("submit", async (e) => {
  e.preventDefault();
  const msg = document.getElementById("membershipMessage");
  const data = Object.fromEntries(new FormData(e.target));

  try {
    const res = await fetch("/api/membership", {
      method: "POST",
      headers: {"Content-Type":"application/json"},
      body: JSON.stringify(data)
    });
    const result = await res.json();
    msg.textContent = result.message;
    if (result.success) e.target.reset();
  } catch {
    msg.textContent = "Server error. Please try again.";
  }
});

document.getElementById("enquiryForm").addEventListener("submit", async (e) => {
  e.preventDefault();
  const msg = document.getElementById("formMessage");
  const data = Object.fromEntries(new FormData(e.target));

  try {
    const res = await fetch("/api/enquiry", {
      method: "POST",
      headers: {"Content-Type":"application/json"},
      body: JSON.stringify(data)
    });
    const result = await res.json();
    msg.textContent = result.message;
    if (result.success) e.target.reset();
  } catch {
    msg.textContent = "Server error. Please try again.";
  }
});

# Shivom Gym — Full-Stack Website

## Features
- Responsive attractive gym landing page
- Programs and membership plans
- Membership request modal
- Contact/enquiry form
- Node.js + Express backend
- SQLite database
- Admin API endpoints for submitted enquiries and memberships

## Run on a computer
1. Install Node.js.
2. Open this project folder in Terminal.
3. Run:
   npm install
   npm start
4. Open http://localhost:3000

## Backend data
A `shivom.db` SQLite database is created automatically.

Admin data endpoints:
- GET `/api/admin/enquiries`
- GET `/api/admin/memberships`

For a real production website, protect admin endpoints with authentication before using them publicly.

## Deploy
Deploy the Node.js project to a host that supports Node.js and persistent SQLite storage. Set the `PORT` environment variable if the host requires it.

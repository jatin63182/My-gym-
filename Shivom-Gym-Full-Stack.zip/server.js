const express = require("express");
const path = require("path");
const Database = require("better-sqlite3");

const app = express();
const PORT = process.env.PORT || 3000;
const db = new Database("shivom.db");

db.exec(`
  CREATE TABLE IF NOT EXISTS enquiries (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    phone TEXT NOT NULL,
    email TEXT,
    goal TEXT,
    message TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS memberships (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    phone TEXT NOT NULL,
    plan TEXT NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );
`);

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, "public")));

app.post("/api/enquiry", (req, res) => {
  const { name, phone, email, goal, message } = req.body;
  if (!name || !phone) {
    return res.status(400).json({ success: false, message: "Name and phone are required." });
  }

  const stmt = db.prepare(`
    INSERT INTO enquiries (name, phone, email, goal, message)
    VALUES (?, ?, ?, ?, ?)
  `);
  const result = stmt.run(name.trim(), phone.trim(), email?.trim() || "", goal || "", message?.trim() || "");

  res.json({ success: true, id: result.lastInsertRowid, message: "Enquiry submitted successfully!" });
});

app.post("/api/membership", (req, res) => {
  const { name, phone, plan } = req.body;
  if (!name || !phone || !plan) {
    return res.status(400).json({ success: false, message: "Name, phone and plan are required." });
  }

  const stmt = db.prepare(`
    INSERT INTO memberships (name, phone, plan)
    VALUES (?, ?, ?)
  `);
  const result = stmt.run(name.trim(), phone.trim(), plan);

  res.json({ success: true, id: result.lastInsertRowid, message: "Membership request received!" });
});

app.get("/api/admin/enquiries", (req, res) => {
  const rows = db.prepare("SELECT * FROM enquiries ORDER BY id DESC").all();
  res.json(rows);
});

app.get("/api/admin/memberships", (req, res) => {
  const rows = db.prepare("SELECT * FROM memberships ORDER BY id DESC").all();
  res.json(rows);
});

app.get("*", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "index.html"));
});

app.listen(PORT, () => {
  console.log(`Shivom Gym running at http://localhost:${PORT}`);
});